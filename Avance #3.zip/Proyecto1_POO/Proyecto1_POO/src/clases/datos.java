/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.util.ArrayList;

/**
 *
 * @author Kevin
 */

public class datos {
    
    public static ArrayList<Profesor> listaProf = new ArrayList<Profesor>();
    public static ArrayList<Coordinador> listaCoor = new ArrayList<Coordinador>();
    
    public static void main(String[] args){
        
        
        Profesor profAux;
        Coordinador coorAux;
        
        coorAux = new Coordinador(01, "01");
        listaCoor.add(coorAux);
        
        profAux = new Profesor(01, "CA", "01");
        listaProf.add(profAux);
        
        profAux = new Profesor(02, "IC", "02");
        listaProf.add(profAux);
        
        profAux = new Profesor(03, "PI", "03");
        listaProf.add(profAux);
        
        new ventanaInicio().setVisible(true);
    }
    
}
