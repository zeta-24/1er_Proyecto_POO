/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Kevin
 */
public class Profesor extends Usuario{
    
    private int cedulaP;
    private String departamentP;

    public Profesor(int cedulaP, String departamentP, String contrasenaP) {
        //super();
        this.cedulaP = cedulaP;
        this.departamentP = departamentP;
        setNombreUsu(cedulaP);
        setContrasenaUsu(contrasenaP);
    }

    public int getCedulaP() {
        return cedulaP;
    }

    public String getDepartamentP() {
        return departamentP;
    }

    public boolean comprobarSesion(int ced, String contraPr) {
        
        //for(int i = 0; i < listaProf.size(); i++){
            //if(listaProf.get(i).getNombreUsu()==ced && listaProf.get(i).getContrasenaUsu().equals(contraPr))
        if(getNombreUsu()==ced && getContrasenaUsu().equals(contraPr))
                return true;
            else
                return false;
            
        }
        //return true;
    //}

    @Override
    public boolean comprobarSesion() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
