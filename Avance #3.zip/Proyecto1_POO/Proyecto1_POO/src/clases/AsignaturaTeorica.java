/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Kevin
 */
public class AsignaturaTeorica  extends Asignatura{
    private String paginaWeb;
    
    public AsignaturaTeorica(String pagWeb, String nombreAs, short creditoAs, boolean escuelaAs, String horaIni, String horaFin, short numAulaAs) {
        this.paginaWeb = pagWeb;
        setNombreAs(nombreAs);
        setCreditoAs(creditoAs);
        setNumAulaAs(numAulaAs);
        setEscuelaAs(escuelaAs);
        setHoraIni(horaIni);
        setHoraFin(horaFin);
    }

    public String getPaginaWeb() {
        return paginaWeb;
    }
}
