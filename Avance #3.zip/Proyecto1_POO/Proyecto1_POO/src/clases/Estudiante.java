/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Tre
 */
public class Estudiante extends Usuario{
    
    private int nCarne;

    public int getnCarne() {
        return nCarne;
    }

    public Estudiante(int nCarne, String contrasenaE) {
        //super();
        this.nCarne = nCarne;
        setNombreUsu(nCarne);
        setContrasenaUsu(contrasenaE);
    }
    
    public boolean comprobarSesion(int carne, String contraEs) {
        if(getNombreUsu()==carne && getContrasenaUsu().equals(contraEs)){
        return true;
        }
        else{
        return false;
        }
    }

    @Override
    public boolean comprobarSesion() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
