/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Kevin
 */
public class AsignaturaPractica extends Asignatura{
    
    private String materialApoyo;
    private String sistemaOperativo;

    public AsignaturaPractica(String materialApoyo, String sistemaOperativo, String nombreAs, short creditoAs, boolean escuelaAs, String horaIni, String horaFin, short numAulaAs) {
        this.materialApoyo = materialApoyo;
        this.sistemaOperativo = sistemaOperativo;
        setNombreAs(nombreAs);
        setCreditoAs(creditoAs);
        setNumAulaAs(numAulaAs);
        setEscuelaAs(escuelaAs);
        setHoraIni(horaIni);
        setHoraFin(horaFin);
    }

    public String getMaterialApoyo() {
        return materialApoyo;
    }

    public String getSistemaOperativo() {
        return sistemaOperativo;
    }
    
    
    
}
