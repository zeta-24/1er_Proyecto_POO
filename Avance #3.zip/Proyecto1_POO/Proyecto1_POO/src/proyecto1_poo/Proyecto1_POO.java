/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1_poo;
//import clases.ventanaInicio;
/**
 *
 * @author Lisbeth
 */
public class Proyecto1_POO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // TODO code application logic here       
    }
}
