/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Lisbeth
 */
public class AsignaturaTeorica  extends Asignatura{
    private String paginaWeb;
    
}
