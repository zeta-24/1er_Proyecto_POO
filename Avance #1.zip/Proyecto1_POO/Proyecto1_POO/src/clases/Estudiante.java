/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Tre
 */
public class Estudiante extends Usuario{
    
    private int nCarne;

    public int getnCarne() {
        return nCarne;
    }

    public void setnCarne(int nCarne) {
        this.nCarne = nCarne;
    }
    
    
    
    
}
