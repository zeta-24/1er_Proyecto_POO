/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Lisbeth
 */
public class Aula {
    private String nombreAul;
    private short numeroAul;
    private String ubicacionAul;
    private short capacidad;

}
