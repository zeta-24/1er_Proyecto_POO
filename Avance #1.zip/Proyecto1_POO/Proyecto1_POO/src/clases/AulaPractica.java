/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Lisbeth
 */
public class AulaPractica extends Aula {
    private short cuantoEquipo;
    private String cualEquipo;

    
    
}
