/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Lisbeth
 */
public class Asignatura {
    private String nombreAs;
    private short creditoAs;
    private boolean escuelaAs;
    private String horaIni;
    private String horaFin;
    private short aulaClase; 
}
