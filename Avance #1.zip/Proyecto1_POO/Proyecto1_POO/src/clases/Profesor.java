/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 *
 * @author Lisbeth
 */
public class Profesor extends Usuario{
    
    private int cedulaP;
    //LinkedList<AsignaturaPractica> cursosP = new LinkedList<AsignaturaPractica>();
    //LinkedList<AsignaturaTeorica> cursosT = new LinkedList<AsignaturaTeorica>();
    private String departamentP;
    
}
