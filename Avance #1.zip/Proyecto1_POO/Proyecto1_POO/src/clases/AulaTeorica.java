/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Lisbeth
 */
public class AulaTeorica extends Aula{
    private boolean aireCondicionado;
    private boolean equipoMulti;

    
}
