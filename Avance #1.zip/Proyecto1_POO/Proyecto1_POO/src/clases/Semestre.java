/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

//import java.util.ArrayList;

/**
 *
 * @author Lisbeth
 */
public class Semestre {
    
    //private ArrayList asignaturaSem= new ArrayList();
    private short numeroAsig;
    private short numeroSemetre;
    
}
