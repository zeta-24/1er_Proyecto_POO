/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Lisbeth
 */
public class AsignaturaPractica extends Asignatura{
    
    private String materialApoyo;
    private String sistemaOperativo;
    
}
