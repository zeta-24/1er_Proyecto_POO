/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 *
 * @author Kevin
 */
public class Profesor extends Usuario{
    
    private int cedulaP;
    //LinkedList<AsignaturaPractica> cursosP = new LinkedList<AsignaturaPractica>();
    //LinkedList<AsignaturaTeorica> cursosT = new LinkedList<AsignaturaTeorica>();
    private String departamentP;

    public Profesor(int cedulaP, String departamentP, String contrasenaP) {
        //super();
        this.cedulaP = cedulaP;
        this.departamentP = departamentP;
        setNombreUsu(cedulaP);
        setContrasenaUsu(contrasenaP);
    }

    

    public int getCedulaP() {
        return cedulaP;
    }

    public String getDepartamentP() {
        return departamentP;
    }

    public boolean comprobarSesion(int ced, String contraPr) {
        if(getNombreUsu()==ced && getContrasenaUsu().equals(contraPr)){
        return true;
        }
        else{
        return false;
        }
    }

    @Override
    public boolean comprobarSesion() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
