/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Kevin
 */
public class Coordinador extends Usuario{
    
    private int cedula;

    public Coordinador(int cedula, String contrasenaC) {
        this.cedula = cedula;
        setNombreUsu(cedula);
        setContrasenaUsu(contrasenaC);
    }

    
        //this.atri = atrib;
    
    //funcion que debe generar el horario por parte de la coordinacion
    public void generarHorario(){
        
    
    }

    @Override
    public boolean comprobarSesion() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
