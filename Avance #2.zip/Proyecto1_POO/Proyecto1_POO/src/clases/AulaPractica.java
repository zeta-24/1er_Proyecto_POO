/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Kevin
 */
public class AulaPractica extends Aula {
    private short cuantoEquipo;
    private String cualEquipo;

    public AulaPractica(short cuantoEquipo, String cualEquipo, String nombreAul, short numeroAul, String ubicacionAul, short capacidadAul) {
        //super(nombreAul, numeroAul, ubicacionAul, capacidad);
        this.cuantoEquipo = cuantoEquipo;
        this.cualEquipo = cualEquipo;
        setNumeroAul(numeroAul);
        setNombreAul(nombreAul);
        setCapacidad(capacidadAul);
        setUbicacionAul(ubicacionAul);
    }

    public short getCuantoEquipo() {
        return cuantoEquipo;
    }

    public String getCualEquipo() {
        return cualEquipo;
    }

    
    
}
