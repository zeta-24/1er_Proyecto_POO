/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Kevin
 */
public class AulaTeorica extends Aula{
    private boolean aireCondicionado;
    private boolean equipoMulti;

    public AulaTeorica(boolean aireCondicionado, boolean equipoMulti, String nombreAul, short numeroAul, String ubicacionAul, short capacidadAul) {
        //super(nombreAul, numeroAul, ubicacionAul, capacidad);
        this.aireCondicionado = aireCondicionado;
        this.equipoMulti = equipoMulti;
        setNumeroAul(numeroAul);
        setNombreAul(nombreAul);
        setCapacidad(capacidadAul);
        setUbicacionAul(ubicacionAul);
    }

    public boolean isAireCondicionado() {
        return aireCondicionado;
    }

    public boolean isEquipoMulti() {
        return equipoMulti;
    }

    
}
