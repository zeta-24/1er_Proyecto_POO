/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Keivn
 */
public abstract class Asignatura {
    private String nombreAs;
    private short creditoAs;
    private boolean escuelaAs;
    private String horaIni;
    private String horaFin;
    private short numAulaAs;

    public String getNombreAs() {
        return nombreAs;
    }

    public void setNombreAs(String nombreAs) {
        this.nombreAs = nombreAs;
    }

    public short getCreditoAs() {
        return creditoAs;
    }

    public void setCreditoAs(short creditoAs) {
        this.creditoAs = creditoAs;
    }

    public boolean isEscuelaAs() {
        return escuelaAs;
    }

    public void setEscuelaAs(boolean escuelaAs) {
        this.escuelaAs = escuelaAs;
    }

    public String getHoraIni() {
        return horaIni;
    }

    public void setHoraIni(String horaIni) {
        this.horaIni = horaIni;
    }

    public String getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(String horaFin) {
        this.horaFin = horaFin;
    }

    public short getNumAulaAs() {
        return numAulaAs;
    }

    public void setNumAulaAs(short numAulaAs) {
        this.numAulaAs = numAulaAs;
    }
     
}
