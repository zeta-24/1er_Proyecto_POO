/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Kevin
 */
public abstract class Usuario {
    private int nombreUsu;
    private String contrasenaUsu;

    public int getNombreUsu() {
        return nombreUsu;
    }

    public String getContrasenaUsu() {
        return contrasenaUsu;
    }

    public void setContrasenaUsu(String contrasenaUsu) {
        this.contrasenaUsu = contrasenaUsu;
    }

    public void setNombreUsu(int nombreUsu) {
        this.nombreUsu = nombreUsu;
    }
    public abstract boolean comprobarSesion();
    
}
