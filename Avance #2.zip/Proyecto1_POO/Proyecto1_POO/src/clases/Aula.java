/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Kevin
 */
public abstract class Aula {
    private String nombreAul;
    private short numeroAul;
    private String ubicacionAul;
    private short capacidad;

    public String getNombreAul() {
        return nombreAul;
    }

    public short getNumeroAul() {
        return numeroAul;
    }

    public String getUbicacionAul() {
        return ubicacionAul;
    }

    public short getCapacidad() {
        return capacidad;
    }

    public void setNombreAul(String nombreAul) {
        this.nombreAul = nombreAul;
    }

    public void setNumeroAul(short numeroAul) {
        this.numeroAul = numeroAul;
    }

    public void setUbicacionAul(String ubicacionAul) {
        this.ubicacionAul = ubicacionAul;
    }

    public void setCapacidad(short capacidad) {
        this.capacidad = capacidad;
    }

    
}
